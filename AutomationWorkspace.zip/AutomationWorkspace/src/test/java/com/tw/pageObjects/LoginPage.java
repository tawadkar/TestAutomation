package com.tw.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.tw.CommonUtils.DriverManager;


public class LoginPage {
	
	@FindBy(id="username")
	public WebElement txtuserName;
	
	@FindBy(id="password")
	public WebElement txtpassword;
	
	@FindBy(id="formly_2_input_username_0")
	public WebElement txtconfirmuserName;

	@FindBy(xpath="//button[@class='btn btn-danger']")
	public WebElement btnLogin;
	
	
	public LoginPage() {		
		PageFactory.initElements(DriverManager.getWebDriver(),this);
	}

}
