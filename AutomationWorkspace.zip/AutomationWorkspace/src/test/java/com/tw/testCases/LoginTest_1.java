package com.tw.testCases;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.tw.CommonUtils.Config;
import com.tw.CommonUtils.DriverManager;
import com.tw.CommonUtils.Logger;
import com.tw.CommonUtils.WebInteract;
import com.tw.Helpers.Login_Helper;
import com.tw.base.BaseTest;
import com.tw.excelUtils.Excel;
import com.tw.pageObjects.LoginPage;

public class LoginTest_1 extends BaseTest {
	
	
	public LoginPage loginPage;  
	public Login_Helper loginHelper;
	
	protected static Map<String, String> testData;
	protected static String className;

	

	
  public LoginTest_1() {
		
		loginPage = new LoginPage();
		loginHelper = new Login_Helper();
			//Load test data
		className = this.getClass().getSimpleName();
		testData = Excel.getTestData(className);
	}
	
    
	
	@Test
	public void verifyLogin() throws InterruptedException {
     loginHelper.launchApplication(Config.APPURL);
   // Assert.assertTrue(status, "Application home page is not displayed.");
   
			
 	/*    if (loginPage.txtuserName.isEnabled()) {
 			//Logger.logMessage("Application launched successfully.");
 	    	System.out.println("Application launched successfully.");
 		}else {
 			System.out.println("Fail");
 		}*/
     
   
 			
 	  
 		
 	    
 	try {
 		
    loginPage.txtuserName.sendKeys("angular");
    }catch(Exception e) {
    	e.printStackTrace();
    }
    
    
  //  loginPage.txtpassword.sendKeys(testData.get("Password"));
  //  loginPage.txtconfirmuserName.sendKeys(testData.get("ConfirmUserName"));
   // loginPage.btnLogin.click();
		
	}
	

}
