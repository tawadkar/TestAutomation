package com.tw.CommonUtils;

import java.net.URL;

import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class DriverManager {
    private static ThreadLocal<RemoteWebDriver> webDriver = new ThreadLocal<RemoteWebDriver>();
  
  	/**
    * Sets the Remote WebDriver instance for the running session.
    * @param driver
    */
    public static synchronized void setWebDriver(RemoteWebDriver driver) {
        webDriver.set(driver);
    }
    
    /**
     * Gets the Remote WebDriver instance for the running session.
     * @return
     */
    public static synchronized RemoteWebDriver getWebDriver() {
        return webDriver.get();
    }
  
    /**
     * Initiates a new instance of Remote WebDriver.
     */
    public static void initiateWebDriver() {
     	DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setBrowserName(Config.BROWSER);
        //capabilities.setCapability("platform", Config.PLATFORM);
        capabilities.setCapability(CapabilityType.TAKES_SCREENSHOT, true);
        
        ChromeOptions options = new ChromeOptions();
    	options.addArguments("start-maximized");
    	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
       
        String hubAddress = "http://" + Config.GRID_HUB_IP + ":" + Config.GRID_HUB_PORT + "/wd/hub";
        try {
        		setWebDriver(new RemoteWebDriver(new URL(hubAddress),capabilities));
        		
        } catch (Exception e) {
            Logger.logConsoleMessage("Session could not be created.");
            e.printStackTrace();
        }
        if (webDriver == null) {
            Logger.logConsoleMessage("The driver was not properly initiated.");
        }   
    }
    
    /**
     * Closes existing instance of Remote WebDriver.
     */
    public static void stopWebDriver() {
    	getWebDriver().close();
		getWebDriver().quit();
		Logger.logConsoleMessage("Closing browser.");
    }
    
}
