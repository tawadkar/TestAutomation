package com.tw.Helpers;

import com.tw.CommonUtils.Config;
import com.tw.CommonUtils.DriverManager;
import com.tw.CommonUtils.WebInteract;
import com.tw.pageObjects.LoginPage;

public class Login_Helper {
	
	public LoginPage loginPage;  
	
	public Login_Helper() {
		
		loginPage = new LoginPage();
	}
	
	public void launchApplication(String appURL) throws InterruptedException  {
		
		
		if (Config.BROWSER.equalsIgnoreCase("firefox") || Config.BROWSER.equalsIgnoreCase("chrome")) {
		//	String url = "https://" + userName + ":" + password + "@" + appURL;
		//	String url1 = "https://" + userName + ":" + password + "@" + appURL1;
			
			WebInteract.openUrl(appURL);
			
			
			Thread.sleep(5000);
			
			
		}
		
	}	
		
	  

	}
